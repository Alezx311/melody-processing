import { Cute } from 'react-cute';

export const ReactJsonCute = ({ src = {} }) => <Cute json={src} />;
